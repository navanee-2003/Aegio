import axios from "axios";
import { useRef } from "react";
import { useState } from "react";

const Home = () => {
  const [url, setUrl] = useState("https://skcet.ac.in");
  const [data, setData] = useState("");
  const [display, setDisplay] = useState(true);
  const progressBar = useRef();

  function progressColor(val) {
    if(val < 30){
      return "red";
    }
    else if(val < 60){
      return "orange";
    }
    else{
      return "green";
    }
  }

  let bgColor = progressColor(data.risk_score || 0);
  console.log('bgColor: ', bgColor)
  
  const key = "zz6iCyWYP1yOk5gxhs6JD5842jW4VCpM";
  const endPoint =
  "https://cors-anywhere.herokuapp.com/https://ipqualityscore.com/api/json/url?key=" +
  key +
  "&url=" +
  url;
  console.log(endPoint);
  const checkHandle = () => {
      axios
      .get(endPoint, {
          method: "GET",
          headers: {
              "IPQS-KEY": "zz6iCyWYP1yOk5gxhs6JD5842jW4VCpM"
            }
        })
        .then((response) => setData(response.data))
        .then(() => {console.log(data)})
        .then(() => {setDisplay(false)})
        .catch((err) => console.log(err));
    };
    return (
        <div className="home-div">
      <div className="home-content">
        <div className="company-name"></div>
        <input
          type="text"
          value={url}
          placeholder="ENTER URL"
          onChange={(e) => setUrl(e.currentTarget.value)}
        />
        <button onClick={checkHandle}>CHECK !</button>
        <div className="message">
          {display && <p>Hello, Pal! We are Happy to Help!</p>}
            {!display && <div className="progress-bar">
                    {!display && <p>{100 - data.risk_score + "%"}</p>}
                <div className="progress" ref= {progressBar} style={{"width" : `${100 - data.risk_score + "%"}`, "backgroundColor": bgColor}}>
                </div>
            </div>}
        </div>
      </div>
    </div>
  );
};

export default Home;